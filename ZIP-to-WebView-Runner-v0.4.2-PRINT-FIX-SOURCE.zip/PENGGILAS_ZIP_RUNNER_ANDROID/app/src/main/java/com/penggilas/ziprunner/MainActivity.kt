package com.penggilas.ziprunner

import android.app.Activity
import android.app.DownloadManager
import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Environment
import android.os.Build
import android.print.PrintAttributes
import android.print.PrintManager
import android.provider.MediaStore
import android.util.Base64
import android.webkit.DownloadListener
import android.webkit.JavascriptInterface
import android.widget.Toast
import android.os.Bundle
import android.content.Intent
import android.graphics.Color
import android.view.View
import android.view.ViewGroup
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import java.io.File
import java.io.FileInputStream
import java.io.InputStream
import java.net.URLDecoder
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import fi.iki.elonen.NanoHTTPD

/** ZIP-to-WebView Runner v0.4.2: fullscreen ZIP WebView with native print/download support. */
class MainActivity : Activity() {
    private lateinit var root: LinearLayout
    private lateinit var web: WebView
    private lateinit var status: TextView
    private lateinit var pickButton: Button
    private lateinit var runnerHeader: LinearLayout
    private lateinit var runnerControls: LinearLayout
    private var server: LocalServer? = null
    private var selectedZip: File? = null
    private var printWebView: WebView? = null
    private val requestCodeZip = 4071
    private val purple = Color.rgb(81, 79, 232)

    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); buildUi() }

    private fun buildUi() {
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.rgb(245, 245, 250)) }
        runnerHeader = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(22, 24, 22, 22); setBackgroundColor(purple) }
        runnerHeader.addView(TextView(this).apply { text = "📦 ZIP-to-WebView Runner"; textSize = 23f; setTextColor(Color.WHITE); setTypeface(null, 1) })
        runnerHeader.addView(TextView(this).apply { text = "PENGGILAS • Jalankan web app langsung dari ZIP"; textSize = 14f; setTextColor(Color.WHITE); setPadding(0, 6, 0, 0) })
        root.addView(runnerHeader)
        runnerControls = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(18, 18, 18, 18) }
        pickButton = Button(this).apply { text = "PILIH FILE ZIP"; setBackgroundColor(purple); setTextColor(Color.WHITE); setOnClickListener { chooseZip() } }
        runnerControls.addView(pickButton, matchWrap())
        status = TextView(this).apply { text = "Siap. Pilih ZIP aplikasi HTML/CSS/JavaScript."; textSize = 14f; setTextColor(Color.DKGRAY); setPadding(4, 14, 4, 14) }
        runnerControls.addView(status)
        runnerControls.addView(Button(this).apply { text = "TUTUP PROYEK"; setOnClickListener { stopProject(); status.text = "Proyek ditutup. Pilih ZIP untuk memulai lagi."; pickButton.text = "PILIH FILE ZIP" } }, matchWrap())
        web = WebView(this).apply {
            visibility = View.GONE
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.databaseEnabled = true
            settings.allowFileAccess = false
            settings.allowContentAccess = false
            settings.mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
            settings.javaScriptCanOpenWindowsAutomatically = false
            webViewClient = object : WebViewClient() {
                override fun onPageFinished(view: WebView, url: String) {
                    super.onPageFinished(view, url)
                    // Android WebView does not implement window.print() by itself.
                    // Route print requests to Android's native print dialog.
                    view.evaluateJavascript("""
                        (function() {
                          function requestPrint(w) {
                            try {
                              if (!w || !w.document || !w.document.documentElement) return;
                              var html = '<!DOCTYPE html>\n' + w.document.documentElement.outerHTML;
                              var bridge = w.ZipRunnerBridge || window.ZipRunnerBridge;
                              if (bridge && bridge.printFrameDocument) {
                                bridge.printFrameDocument(html, w.location.href);
                              } else {
                                console.error('ZIP Runner print bridge unavailable');
                              }
                            } catch (e) { console.error('ZIP Runner print failed', e); }
                          }
                          function hook(w) {
                            try {
                              if (!w || !w.document || w.__zipRunnerPrintHook) return;
                              w.__zipRunnerPrintHook = true;
                              // Handle JavaScript window.print() calls from this document/frame.
                              w.print = function() { requestPrint(w); };
                              // Also handle the visible report button directly. This covers pages
                              // where inline onclick handlers run before a frame was hooked.
                              w.document.addEventListener('click', function(ev) {
                                var el = ev.target && ev.target.closest ? ev.target.closest('button, input[type=button], input[type=submit], a') : null;
                                if (!el) return;
                                var label = ((el.innerText || el.value || el.getAttribute('aria-label') || '') + ' ' + (el.getAttribute('onclick') || '')).toLowerCase();
                                if (label.indexOf('print') !== -1 || label.indexOf('save pdf') !== -1 || label.indexOf('window.print') !== -1) {
                                  ev.preventDefault();
                                  ev.stopPropagation();
                                  if (ev.stopImmediatePropagation) ev.stopImmediatePropagation();
                                  requestPrint(w);
                                  return;
                                }
                                var a = el.matches && el.matches('a[download]') ? el : null;
                                if (!a) return;
                                var href = a.href || '';
                                if (href.indexOf('blob:') === 0 || href.indexOf('data:') === 0) {
                                  ev.preventDefault();
                                  w.fetch(href).then(function(r){ return r.blob(); }).then(function(blob) {
                                    var reader = new w.FileReader();
                                    reader.onloadend = function() {
                                      var data = String(reader.result || '').split(',')[1] || '';
                                      var bridge = w.ZipRunnerBridge || window.ZipRunnerBridge;
                                      if (bridge) bridge.saveBase64(a.download || 'download', blob.type || 'application/octet-stream', data);
                                    };
                                    reader.readAsDataURL(blob);
                                  }).catch(function(e){ console.error('Download gagal', e); });
                                }
                              }, true);
                              var scan = function() {
                                var frames = w.document.querySelectorAll('iframe, frame');
                                frames.forEach(function(frame) {
                                  try {
                                    if (frame.contentWindow && frame.contentWindow.document) hook(frame.contentWindow);
                                  } catch(e) { /* cross-origin frame: cannot inspect */ }
                                });
                              };
                              scan();
                              w.document.addEventListener('load', scan, true);
                              if (w.MutationObserver && w.document.documentElement) {
                                new w.MutationObserver(scan).observe(w.document.documentElement, {childList:true, subtree:true});
                              }
                              // Some apps create/navigate their report iframe after initial load.
                              var attempts = 0;
                              var timer = w.setInterval(function() {
                                scan();
                                if (++attempts >= 40) w.clearInterval(timer);
                              }, 500);
                            } catch(e) { console.error('ZIP Runner hook failed', e); }
                          }
                          hook(window);
                        })();
                    """.trimIndent(), null)
                }
            }
            webChromeClient = WebChromeClient()
            addJavascriptInterface(ZipRunnerBridge(this@MainActivity), "ZipRunnerBridge")
            setDownloadListener(DownloadListener { url, userAgent, contentDisposition, mimeType, _ ->
                downloadUrl(url, userAgent, contentDisposition, mimeType)
            })
        }
        root.addView(runnerControls)
        root.addView(web, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)
    }

    private fun matchWrap() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = 8 }

    private fun chooseZip() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "application/zip"
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("application/zip", "application/x-zip-compressed", "application/octet-stream", "application/x-zip"))
        }
        startActivityForResult(intent, requestCodeZip)
    }

    @Deprecated("Android document picker callback")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != requestCodeZip || resultCode != Activity.RESULT_OK) return
        val uri = data?.data ?: return
        pickButton.isEnabled = false
        status.text = "Menyalin arsip ZIP dan memeriksa strukturnya…"
        Thread {
            var dest: File? = null
            try {
                val base = File(filesDir, "zip_projects").apply { mkdirs() }
                dest = File(base, "project_${System.currentTimeMillis()}.zip")
                contentResolver.openInputStream(uri)?.use { input -> dest!!.outputStream().buffered().use { output -> input.copyTo(output) } }
                    ?: error("File ZIP tidak bisa dibaca")
                val start = findStartPageInZip(dest!!)
                runOnUiThread {
                    try {
                        stopProject()
                        selectedZip = dest
                        server = LocalServer(dest!!).also { it.start(NanoHTTPD.SOCKET_READ_TIMEOUT, false) }
                        web.visibility = View.VISIBLE
                        runnerHeader.visibility = View.GONE
                        runnerControls.visibility = View.GONE
                        enterImmersiveMode()
                        web.loadUrl("http://127.0.0.1:8080/${encodeRelativePath(start)}")
                        status.text = "Berjalan dari ZIP: $start\nBerkas dibaca langsung dari arsip; tidak diekstrak menjadi folder."
                        pickButton.text = "PILIH ZIP LAIN"
                    } catch (e: Exception) {
                        dest?.delete(); status.text = "Gagal memulai server lokal: ${e.message ?: "kesalahan tidak diketahui"}"
                    } finally { pickButton.isEnabled = true }
                }
            } catch (e: Exception) {
                dest?.delete()
                runOnUiThread { status.text = "Gagal membuka ZIP: ${e.message ?: "arsip tidak valid"}"; pickButton.isEnabled = true }
            }
        }.start()
    }

    /** Validates archive entries and finds the HTML entry point without extracting them. */
    private fun findStartPageInZip(file: File): String {
        ZipFile(file).use { zip ->
            val html = mutableListOf<String>()
            var count = 0
            var expanded = 0L
            val entries = zip.entries()
            while (entries.hasMoreElements()) {
                val entry = entries.nextElement()
                count++
                require(count <= 20000) { "ZIP memiliki terlalu banyak entri (maksimum 20.000)" }
                val name = entry.name.replace('\\', '/')
                require(!name.startsWith("/") && name.split('/').none { it == ".." }) { "ZIP ditolak: jalur entri tidak aman" }
                if (!entry.isDirectory) {
                    if (entry.size > 0) expanded += entry.size
                    require(expanded <= 500L * 1024L * 1024L) { "Ukuran isi ZIP melebihi batas 500 MiB" }
                    if (name.substringAfterLast('.', "").lowercase() in listOf("html", "htm")) html.add(name)
                }
            }
            return html.firstOrNull { it.substringAfterLast('/').equals("index.html", true) }
                ?: html.firstOrNull { it.substringAfterLast('/').equals("default.html", true) }
                ?: html.minByOrNull { it.count { c -> c == '/' } }
                ?: error("Tidak ditemukan index.html, default.html, atau halaman HTML")
        }
    }

    private fun encodeRelativePath(path: String): String = path.split("/").joinToString("/") {
        java.net.URLEncoder.encode(it, "UTF-8").replace("+", "%20")
    }


    /** Hide Android system bars while a ZIP app is running. */
    @Suppress("DEPRECATION")
    private fun enterImmersiveMode() {
        window.decorView.systemUiVisibility = (
            View.SYSTEM_UI_FLAG_FULLSCREEN
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
        )
    }

    @Suppress("DEPRECATION")
    private fun exitImmersiveMode() {
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_VISIBLE
    }

    private fun printFrameDocument(html: String, baseUrl: String) {
        try {
            // Print the actual document that called window.print(), not the ZIP wrapper/index page.
            runOnUiThread {
                try {
                    printWebView?.let { old ->
                        (old.parent as? ViewGroup)?.removeView(old)
                        old.destroy()
                    }
                    val printView = WebView(this).apply {
                        settings.javaScriptEnabled = true
                        settings.domStorageEnabled = true
                        settings.allowFileAccess = false
                        settings.allowContentAccess = false
                        alpha = 0f
                    }
                    printWebView = printView
                    root.addView(printView, LinearLayout.LayoutParams(1, 1))
                    printView.webViewClient = object : WebViewClient() {
                        override fun onPageFinished(view: WebView, url: String) {
                            super.onPageFinished(view, url)
                            view.postDelayed({
                                try {
                                    val printManager = getSystemService(Context.PRINT_SERVICE) as PrintManager
                                    val adapter = view.createPrintDocumentAdapter("PENGGILAS-Report")
                                    printManager.print("PENGGILAS - Laporan", adapter, PrintAttributes.Builder().build())
                                } catch (e: Exception) {
                                    Toast.makeText(this@MainActivity, "Tidak dapat membuka cetak: ${e.message ?: "kesalahan"}", Toast.LENGTH_LONG).show()
                                }
                            }, 900)
                        }
                    }
                    printView.loadDataWithBaseURL(baseUrl, html, "text/html", "UTF-8", null)
                } catch (e: Exception) {
                    Toast.makeText(this, "Tidak dapat menyiapkan laporan untuk cetak: ${e.message ?: "kesalahan"}", Toast.LENGTH_LONG).show()
                }
            }
        } catch (e: Exception) {
            Toast.makeText(this, "Tidak dapat membuka cetak: ${e.message ?: "kesalahan"}", Toast.LENGTH_LONG).show()
        }
    }

    private fun downloadUrl(url: String, userAgent: String?, contentDisposition: String?, mimeType: String?) {
        try {
            if (url.startsWith("blob:") || url.startsWith("data:")) {
                Toast.makeText(this, "Unduhan blob/data diproses melalui jembatan aplikasi jika tautan memiliki atribut download.", Toast.LENGTH_LONG).show()
                return
            }
            val request = DownloadManager.Request(Uri.parse(url)).apply {
                setTitle(URLUtilCompat.fileName(contentDisposition, url))
                setDescription("Mengunduh berkas dari aplikasi ZIP")
                setMimeType(mimeType ?: "application/octet-stream")
                setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, URLUtilCompat.fileName(contentDisposition, url))
                allowScanningByMediaScanner()
                if (!userAgent.isNullOrBlank()) addRequestHeader("User-Agent", userAgent)
            }
            val manager = getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
            manager.enqueue(request)
            Toast.makeText(this, "Unduhan dimulai. Periksa folder Download.", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Unduhan gagal: ${e.message ?: "kesalahan"}", Toast.LENGTH_LONG).show()
        }
    }

    private inner class ZipRunnerBridge(private val activity: Activity) {
        @JavascriptInterface
        fun printFrameDocument(html: String?, baseUrl: String?) {
            if (html.isNullOrBlank()) {
                runOnUiThread { Toast.makeText(this@MainActivity, "Konten laporan kosong.", Toast.LENGTH_LONG).show() }
                return
            }
            val safeBase = baseUrl?.takeIf { it.startsWith("http://127.0.0.1:8080/") || it.startsWith("https://") || it.startsWith("http://") }
                ?: "http://127.0.0.1:8080/"
            printFrameDocument(html, safeBase)
        }

        @JavascriptInterface
        fun saveBase64(fileName: String?, mimeType: String?, data: String?) {
            Thread {
                try {
                    val safeName = URLUtilCompat.safeName(fileName ?: "download")
                    val bytes = Base64.decode(data ?: "", Base64.DEFAULT)
                    val values = ContentValues().apply {
                        put(MediaStore.Downloads.DISPLAY_NAME, safeName)
                        put(MediaStore.Downloads.MIME_TYPE, mimeType ?: "application/octet-stream")
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) put(MediaStore.Downloads.IS_PENDING, 1)
                    }
                    val collection = MediaStore.Downloads.EXTERNAL_CONTENT_URI
                    val uri = contentResolver.insert(collection, values) ?: error("Tidak dapat membuat berkas di Download")
                    contentResolver.openOutputStream(uri)?.use { it.write(bytes) } ?: error("Tidak dapat menyimpan berkas")
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        val done = ContentValues().apply { put(MediaStore.Downloads.IS_PENDING, 0) }
                        contentResolver.update(uri, done, null, null)
                    }
                    runOnUiThread { Toast.makeText(this@MainActivity, "Tersimpan di Download: $safeName", Toast.LENGTH_LONG).show() }
                } catch (e: Exception) {
                    runOnUiThread { Toast.makeText(this@MainActivity, "Gagal menyimpan: ${e.message ?: "kesalahan"}", Toast.LENGTH_LONG).show() }
                }
            }.start()
        }
    }

    private object URLUtilCompat {
        fun fileName(contentDisposition: String?, url: String): String {
            val fromHeader = contentDisposition?.let { android.webkit.URLUtil.guessFileName(url, it, null) }
            return safeName(fromHeader ?: Uri.parse(url).lastPathSegment ?: "download")
        }
        fun safeName(name: String): String {
            val cleaned = name.substringAfterLast('/').substringAfterLast('\\').replace(Regex("[^A-Za-z0-9._ -]"), "_").trim()
            return cleaned.takeIf { it.isNotBlank() && it != "." && it != ".." } ?: "download"
        }
    }

    private fun stopProject() {
        server?.stop(); server = null
        if (::web.isInitialized) {
            web.stopLoading()
            web.loadUrl("about:blank")
            web.visibility = View.GONE
            runnerHeader.visibility = View.VISIBLE
            runnerControls.visibility = View.VISIBLE
            exitImmersiveMode()
        }
        selectedZip = null
    }

    override fun onBackPressed() {
        if (::web.isInitialized && web.visibility == View.VISIBLE) {
            if (web.canGoBack()) {
                web.goBack()
            } else {
                stopProject()
                status.text = "Proyek ditutup. Pilih ZIP untuk memulai lagi."
                pickButton.text = "PILIH FILE ZIP"
            }
        } else {
            super.onBackPressed()
        }
    }
    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus && ::web.isInitialized && web.visibility == View.VISIBLE) enterImmersiveMode()
    }

    override fun onDestroy() { server?.stop(); super.onDestroy() }

    private class LocalServer(private val archiveFile: File) : NanoHTTPD("127.0.0.1", 8080) {
        override fun serve(session: IHTTPSession): Response {
            if (session.method != Method.GET && session.method != Method.HEAD) {
                return newFixedLengthResponse(Response.Status.METHOD_NOT_ALLOWED, "text/plain; charset=utf-8", "Method not allowed")
            }
            val raw = session.uri.substringBefore('?').ifBlank { "/" }
            val parts = raw.removePrefix("/").split("/").filter { it.isNotEmpty() }
            val decoded = try { parts.joinToString("/") { URLDecoder.decode(it.replace("+", "%2B"), "UTF-8") } } catch (_: Exception) { return newFixedLengthResponse(Response.Status.BAD_REQUEST, "text/plain", "Bad path") }
            val relative = decoded.ifBlank { "index.html" }
            if (relative.startsWith('/') || relative.split('/').any { it == ".." || it == "." }) {
                return newFixedLengthResponse(Response.Status.FORBIDDEN, "text/plain", "Forbidden")
            }
            return try {
                val zip = ZipFile(archiveFile)
                var entry: ZipEntry? = zip.getEntry(relative)
                if (entry == null && relative.endsWith("/")) entry = zip.getEntry(relative + "index.html")
                if (entry == null || entry.isDirectory) {
                    zip.close()
                    return newFixedLengthResponse(Response.Status.NOT_FOUND, "text/plain; charset=utf-8", "Berkas tidak ditemukan di ZIP: $relative")
                }
                val mime = mimeFor(entry.name)
                if (session.method == Method.HEAD) {
                    zip.close()
                    return newFixedLengthResponse(Response.Status.OK, mime, "")
                }
                val rawStream = zip.getInputStream(entry)
                val managed = object : java.io.FilterInputStream(rawStream) {
                    override fun close() { try { super.close() } finally { zip.close() } }
                }
                newFixedLengthResponse(Response.Status.OK, mime, managed, entry.size).apply {
                    addHeader("Cache-Control", "no-cache")
                    addHeader("X-Content-Type-Options", "nosniff")
                    addHeader("Access-Control-Allow-Origin", "*")
                    addHeader("Accept-Ranges", "none")
                }
            } catch (e: Exception) {
                newFixedLengthResponse(Response.Status.INTERNAL_ERROR, "text/plain; charset=utf-8", "Gagal membaca arsip ZIP")
            }
        }

        private fun mimeFor(name: String): String = when (name.substringAfterLast('.', "").lowercase()) {
            "html", "htm" -> "text/html; charset=utf-8"
            "css" -> "text/css; charset=utf-8"
            "js", "mjs", "cjs" -> "text/javascript; charset=utf-8"
            "json", "webmanifest", "map" -> "application/json; charset=utf-8"
            "svg" -> "image/svg+xml"
            "png" -> "image/png"
            "jpg", "jpeg" -> "image/jpeg"
            "gif" -> "image/gif"
            "webp" -> "image/webp"
            "ico" -> "image/x-icon"
            "woff" -> "font/woff"
            "woff2" -> "font/woff2"
            "ttf" -> "font/ttf"
            "otf" -> "font/otf"
            "pdf" -> "application/pdf"
            "txt" -> "text/plain; charset=utf-8"
            "xml" -> "application/xml; charset=utf-8"
            "mp3" -> "audio/mpeg"
            "mp4" -> "video/mp4"
            else -> "application/octet-stream"
        }
    }
}
