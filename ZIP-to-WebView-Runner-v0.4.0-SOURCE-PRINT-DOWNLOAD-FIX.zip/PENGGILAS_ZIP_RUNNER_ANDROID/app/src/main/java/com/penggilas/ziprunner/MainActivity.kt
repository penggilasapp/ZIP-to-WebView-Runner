package com.penggilas.ziprunner

import android.app.Activity
import android.app.DownloadManager
import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Environment
import android.os.Build
import android.print.PrintAttributes
import android.print.PrintManager
import android.provider.MediaStore
import android.util.Base64
import android.webkit.DownloadListener
import android.webkit.JavascriptInterface
import android.widget.Toast
import android.os.Bundle
import android.content.Intent
import android.graphics.Color
import android.view.View
import android.view.ViewGroup
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import java.io.File
import java.io.FileInputStream
import java.io.InputStream
import java.net.URLDecoder
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import fi.iki.elonen.NanoHTTPD

/** ZIP-to-WebView Runner v0.4.0: serve entries directly from the selected ZIP. */
class MainActivity : Activity() {
    private lateinit var root: LinearLayout
    private lateinit var web: WebView
    private lateinit var status: TextView
    private lateinit var pickButton: Button
    private var server: LocalServer? = null
    private var selectedZip: File? = null
    private val requestCodeZip = 4071
    private val purple = Color.rgb(81, 79, 232)

    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); buildUi() }

    private fun buildUi() {
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.rgb(245, 245, 250)) }
        val header = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(22, 24, 22, 22); setBackgroundColor(purple) }
        header.addView(TextView(this).apply { text = "📦 ZIP-to-WebView Runner"; textSize = 23f; setTextColor(Color.WHITE); setTypeface(null, 1) })
        header.addView(TextView(this).apply { text = "PENGGILAS • Jalankan web app langsung dari ZIP"; textSize = 14f; setTextColor(Color.WHITE); setPadding(0, 6, 0, 0) })
        root.addView(header)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(18, 18, 18, 18) }
        pickButton = Button(this).apply { text = "PILIH FILE ZIP"; setBackgroundColor(purple); setTextColor(Color.WHITE); setOnClickListener { chooseZip() } }
        content.addView(pickButton, matchWrap())
        status = TextView(this).apply { text = "Siap. Pilih ZIP aplikasi HTML/CSS/JavaScript."; textSize = 14f; setTextColor(Color.DKGRAY); setPadding(4, 14, 4, 14) }
        content.addView(status)
        content.addView(Button(this).apply { text = "TUTUP PROYEK"; setOnClickListener { stopProject(); status.text = "Proyek ditutup. Pilih ZIP untuk memulai lagi."; pickButton.text = "PILIH FILE ZIP" } }, matchWrap())
        web = WebView(this).apply {
            visibility = View.GONE
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.databaseEnabled = true
            settings.allowFileAccess = false
            settings.allowContentAccess = false
            settings.mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
            settings.javaScriptCanOpenWindowsAutomatically = false
            webViewClient = object : WebViewClient() {
                override fun onPageFinished(view: WebView, url: String) {
                    super.onPageFinished(view, url)
                    // Android WebView does not implement window.print() by itself.
                    // Route print requests to Android's native print dialog.
                    view.evaluateJavascript("""
                        (function() {
                          function hook(w) {
                            try {
                              if (!w || w.__zipRunnerPrintHook) return;
                              w.__zipRunnerPrintHook = true;
                              w.print = function() { window.ZipRunnerBridge.printPage(); };
                              w.document.addEventListener('click', function(ev) {
                                var a = ev.target && ev.target.closest ? ev.target.closest('a[download]') : null;
                                if (!a) return;
                                var href = a.href || '';
                                if (href.indexOf('blob:') === 0 || href.indexOf('data:') === 0) {
                                  ev.preventDefault();
                                  w.fetch(href).then(function(r){ return r.blob(); }).then(function(blob) {
                                    var reader = new w.FileReader();
                                    reader.onloadend = function() {
                                      var data = String(reader.result || '').split(',')[1] || '';
                                      window.ZipRunnerBridge.saveBase64(a.download || 'download', blob.type || 'application/octet-stream', data);
                                    };
                                    reader.readAsDataURL(blob);
                                  }).catch(function(e){ console.error('Download gagal', e); });
                                }
                              }, true);
                              var scan = function() {
                                var frames = w.document.querySelectorAll('iframe');
                                frames.forEach(function(frame) { try { hook(frame.contentWindow); } catch(e) {} });
                              };
                              scan();
                              w.document.addEventListener('load', scan, true);
                            } catch(e) {}
                          }
                          hook(window);
                        })();
                    """.trimIndent(), null)
                }
            }
            webChromeClient = WebChromeClient()
            addJavascriptInterface(ZipRunnerBridge(this@MainActivity), "ZipRunnerBridge")
            setDownloadListener(DownloadListener { url, userAgent, contentDisposition, mimeType, _ ->
                downloadUrl(url, userAgent, contentDisposition, mimeType)
            })
        }
        root.addView(content)
        root.addView(web, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)
    }

    private fun matchWrap() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = 8 }

    private fun chooseZip() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "application/zip"
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("application/zip", "application/x-zip-compressed", "application/octet-stream", "application/x-zip"))
        }
        startActivityForResult(intent, requestCodeZip)
    }

    @Deprecated("Android document picker callback")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != requestCodeZip || resultCode != Activity.RESULT_OK) return
        val uri = data?.data ?: return
        pickButton.isEnabled = false
        status.text = "Menyalin arsip ZIP dan memeriksa strukturnya…"
        Thread {
            var dest: File? = null
            try {
                val base = File(filesDir, "zip_projects").apply { mkdirs() }
                dest = File(base, "project_${System.currentTimeMillis()}.zip")
                contentResolver.openInputStream(uri)?.use { input -> dest!!.outputStream().buffered().use { output -> input.copyTo(output) } }
                    ?: error("File ZIP tidak bisa dibaca")
                val start = findStartPageInZip(dest!!)
                runOnUiThread {
                    try {
                        stopProject()
                        selectedZip = dest
                        server = LocalServer(dest!!).also { it.start(NanoHTTPD.SOCKET_READ_TIMEOUT, false) }
                        web.visibility = View.VISIBLE
                        web.loadUrl("http://127.0.0.1:8080/${encodeRelativePath(start)}")
                        status.text = "Berjalan dari ZIP: $start\nBerkas dibaca langsung dari arsip; tidak diekstrak menjadi folder."
                        pickButton.text = "PILIH ZIP LAIN"
                    } catch (e: Exception) {
                        dest?.delete(); status.text = "Gagal memulai server lokal: ${e.message ?: "kesalahan tidak diketahui"}"
                    } finally { pickButton.isEnabled = true }
                }
            } catch (e: Exception) {
                dest?.delete()
                runOnUiThread { status.text = "Gagal membuka ZIP: ${e.message ?: "arsip tidak valid"}"; pickButton.isEnabled = true }
            }
        }.start()
    }

    /** Validates archive entries and finds the HTML entry point without extracting them. */
    private fun findStartPageInZip(file: File): String {
        ZipFile(file).use { zip ->
            val html = mutableListOf<String>()
            var count = 0
            var expanded = 0L
            val entries = zip.entries()
            while (entries.hasMoreElements()) {
                val entry = entries.nextElement()
                count++
                require(count <= 20000) { "ZIP memiliki terlalu banyak entri (maksimum 20.000)" }
                val name = entry.name.replace('\\', '/')
                require(!name.startsWith("/") && name.split('/').none { it == ".." }) { "ZIP ditolak: jalur entri tidak aman" }
                if (!entry.isDirectory) {
                    if (entry.size > 0) expanded += entry.size
                    require(expanded <= 500L * 1024L * 1024L) { "Ukuran isi ZIP melebihi batas 500 MiB" }
                    if (name.substringAfterLast('.', "").lowercase() in listOf("html", "htm")) html.add(name)
                }
            }
            return html.firstOrNull { it.substringAfterLast('/').equals("index.html", true) }
                ?: html.firstOrNull { it.substringAfterLast('/').equals("default.html", true) }
                ?: html.minByOrNull { it.count { c -> c == '/' } }
                ?: error("Tidak ditemukan index.html, default.html, atau halaman HTML")
        }
    }

    private fun encodeRelativePath(path: String): String = path.split("/").joinToString("/") {
        java.net.URLEncoder.encode(it, "UTF-8").replace("+", "%20")
    }


    private fun printCurrentPage() {
        try {
            val printManager = getSystemService(Context.PRINT_SERVICE) as PrintManager
            val adapter = web.createPrintDocumentAdapter("ZIP-Runner-Report")
            printManager.print("ZIP Runner - Laporan", adapter, PrintAttributes.Builder().build())
        } catch (e: Exception) {
            Toast.makeText(this, "Tidak dapat membuka cetak: ${e.message ?: "kesalahan"}", Toast.LENGTH_LONG).show()
        }
    }

    private fun downloadUrl(url: String, userAgent: String?, contentDisposition: String?, mimeType: String?) {
        try {
            if (url.startsWith("blob:") || url.startsWith("data:")) {
                Toast.makeText(this, "Unduhan blob/data diproses melalui jembatan aplikasi jika tautan memiliki atribut download.", Toast.LENGTH_LONG).show()
                return
            }
            val request = DownloadManager.Request(Uri.parse(url)).apply {
                setTitle(URLUtilCompat.fileName(contentDisposition, url))
                setDescription("Mengunduh berkas dari aplikasi ZIP")
                setMimeType(mimeType ?: "application/octet-stream")
                setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, URLUtilCompat.fileName(contentDisposition, url))
                allowScanningByMediaScanner()
                if (!userAgent.isNullOrBlank()) addRequestHeader("User-Agent", userAgent)
            }
            val manager = getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
            manager.enqueue(request)
            Toast.makeText(this, "Unduhan dimulai. Periksa folder Download.", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Unduhan gagal: ${e.message ?: "kesalahan"}", Toast.LENGTH_LONG).show()
        }
    }

    private inner class ZipRunnerBridge(private val activity: Activity) {
        @JavascriptInterface
        fun printPage() { runOnUiThread { printCurrentPage() } }

        @JavascriptInterface
        fun saveBase64(fileName: String?, mimeType: String?, data: String?) {
            Thread {
                try {
                    val safeName = URLUtilCompat.safeName(fileName ?: "download")
                    val bytes = Base64.decode(data ?: "", Base64.DEFAULT)
                    val values = ContentValues().apply {
                        put(MediaStore.Downloads.DISPLAY_NAME, safeName)
                        put(MediaStore.Downloads.MIME_TYPE, mimeType ?: "application/octet-stream")
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) put(MediaStore.Downloads.IS_PENDING, 1)
                    }
                    val collection = MediaStore.Downloads.EXTERNAL_CONTENT_URI
                    val uri = contentResolver.insert(collection, values) ?: error("Tidak dapat membuat berkas di Download")
                    contentResolver.openOutputStream(uri)?.use { it.write(bytes) } ?: error("Tidak dapat menyimpan berkas")
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        val done = ContentValues().apply { put(MediaStore.Downloads.IS_PENDING, 0) }
                        contentResolver.update(uri, done, null, null)
                    }
                    runOnUiThread { Toast.makeText(this@MainActivity, "Tersimpan di Download: $safeName", Toast.LENGTH_LONG).show() }
                } catch (e: Exception) {
                    runOnUiThread { Toast.makeText(this@MainActivity, "Gagal menyimpan: ${e.message ?: "kesalahan"}", Toast.LENGTH_LONG).show() }
                }
            }.start()
        }
    }

    private object URLUtilCompat {
        fun fileName(contentDisposition: String?, url: String): String {
            val fromHeader = contentDisposition?.let { android.webkit.URLUtil.guessFileName(url, it, null) }
            return safeName(fromHeader ?: Uri.parse(url).lastPathSegment ?: "download")
        }
        fun safeName(name: String): String {
            val cleaned = name.substringAfterLast('/').substringAfterLast('\\').replace(Regex("[^A-Za-z0-9._ -]"), "_").trim()
            return cleaned.takeIf { it.isNotBlank() && it != "." && it != ".." } ?: "download"
        }
    }

    private fun stopProject() {
        server?.stop(); server = null
        if (::web.isInitialized) { web.stopLoading(); web.loadUrl("about:blank"); web.visibility = View.GONE }
        selectedZip = null
    }

    override fun onBackPressed() {
        if (::web.isInitialized && web.visibility == View.VISIBLE && web.canGoBack()) web.goBack() else super.onBackPressed()
    }
    override fun onDestroy() { server?.stop(); super.onDestroy() }

    private class LocalServer(private val archiveFile: File) : NanoHTTPD("127.0.0.1", 8080) {
        override fun serve(session: IHTTPSession): Response {
            if (session.method != Method.GET && session.method != Method.HEAD) {
                return newFixedLengthResponse(Response.Status.METHOD_NOT_ALLOWED, "text/plain; charset=utf-8", "Method not allowed")
            }
            val raw = session.uri.substringBefore('?').ifBlank { "/" }
            val parts = raw.removePrefix("/").split("/").filter { it.isNotEmpty() }
            val decoded = try { parts.joinToString("/") { URLDecoder.decode(it.replace("+", "%2B"), "UTF-8") } } catch (_: Exception) { return newFixedLengthResponse(Response.Status.BAD_REQUEST, "text/plain", "Bad path") }
            val relative = decoded.ifBlank { "index.html" }
            if (relative.startsWith('/') || relative.split('/').any { it == ".." || it == "." }) {
                return newFixedLengthResponse(Response.Status.FORBIDDEN, "text/plain", "Forbidden")
            }
            return try {
                val zip = ZipFile(archiveFile)
                var entry: ZipEntry? = zip.getEntry(relative)
                if (entry == null && relative.endsWith("/")) entry = zip.getEntry(relative + "index.html")
                if (entry == null || entry.isDirectory) {
                    zip.close()
                    return newFixedLengthResponse(Response.Status.NOT_FOUND, "text/plain; charset=utf-8", "Berkas tidak ditemukan di ZIP: $relative")
                }
                val mime = mimeFor(entry.name)
                if (session.method == Method.HEAD) {
                    zip.close()
                    return newFixedLengthResponse(Response.Status.OK, mime, "")
                }
                val rawStream = zip.getInputStream(entry)
                val managed = object : java.io.FilterInputStream(rawStream) {
                    override fun close() { try { super.close() } finally { zip.close() } }
                }
                newFixedLengthResponse(Response.Status.OK, mime, managed, entry.size).apply {
                    addHeader("Cache-Control", "no-cache")
                    addHeader("X-Content-Type-Options", "nosniff")
                    addHeader("Access-Control-Allow-Origin", "*")
                    addHeader("Accept-Ranges", "none")
                }
            } catch (e: Exception) {
                newFixedLengthResponse(Response.Status.INTERNAL_ERROR, "text/plain; charset=utf-8", "Gagal membaca arsip ZIP")
            }
        }

        private fun mimeFor(name: String): String = when (name.substringAfterLast('.', "").lowercase()) {
            "html", "htm" -> "text/html; charset=utf-8"
            "css" -> "text/css; charset=utf-8"
            "js", "mjs", "cjs" -> "text/javascript; charset=utf-8"
            "json", "webmanifest", "map" -> "application/json; charset=utf-8"
            "svg" -> "image/svg+xml"
            "png" -> "image/png"
            "jpg", "jpeg" -> "image/jpeg"
            "gif" -> "image/gif"
            "webp" -> "image/webp"
            "ico" -> "image/x-icon"
            "woff" -> "font/woff"
            "woff2" -> "font/woff2"
            "ttf" -> "font/ttf"
            "otf" -> "font/otf"
            "pdf" -> "application/pdf"
            "txt" -> "text/plain; charset=utf-8"
            "xml" -> "application/xml; charset=utf-8"
            "mp3" -> "audio/mpeg"
            "mp4" -> "video/mp4"
            else -> "application/octet-stream"
        }
    }
}
