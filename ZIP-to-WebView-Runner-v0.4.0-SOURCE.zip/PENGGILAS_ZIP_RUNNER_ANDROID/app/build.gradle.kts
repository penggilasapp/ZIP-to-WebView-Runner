plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.penggilas.ziprunner"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.penggilas.ziprunner"
        minSdk = 24
        targetSdk = 35
        versionCode = 4
        versionName = "0.4.0"
    }
}

dependencies {
    implementation("org.nanohttpd:nanohttpd:2.3.1")
}
